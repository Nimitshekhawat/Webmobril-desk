import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gymapp/Widgets/profilepage.dart';
import 'package:gymapp/home1.dart';
import 'package:gymapp/richtext.dart' as http;

class Editprofile extends StatefulWidget {

  final String p_fullname;
  final String p_phoneno;
  final String p_Gmail;
  final String p_dob;
  final String p_gender;
  final String p_height;
  final String p_weight;
  Editprofile(
      this.p_fullname,
      this.p_phoneno,
      this.p_Gmail,
      this.p_dob,
      this.p_gender,
      this.p_height,
      this.p_weight,
      );

  @override
  _profile createState() => _profile();
}

class _profile extends State<Editprofile> {

  TextEditingController firstname = TextEditingController();

  TextEditingController mobilenumber = TextEditingController();
  TextEditingController emailadd = TextEditingController();
  TextEditingController dob = TextEditingController();

  TextEditingController gender = TextEditingController();

  TextEditingController height = TextEditingController();
  TextEditingController weight = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      firstname.text= widget.p_fullname;
      mobilenumber.text= widget.p_phoneno;
      emailadd.text= widget.p_Gmail;
      dob.text=widget.p_dob;
      gender.text= widget.p_gender;
      height.text= widget.p_height;
      weight.text= widget.p_weight;


    });
  }

  late final String? prefixt;



  var arrNames = [
    'Full Name ', 'Mobile Number', 'Email Address', 'Dob' ,'Gender',
    'Height', 'Weight'
  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edit Profile',
          style: TextStyle(fontFamily: 'Koulen', fontSize: 24),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              Center(
                child: Container(
                  height: 160,
                  width: 160,
                  child: Stack(
                    children: [
                  Center(
                  child: SizedBox(
                  height: 150,
                    width: 150,
                    child: CircleAvatar(
                      minRadius: 150,
                      maxRadius: 150,
                      backgroundImage: AssetImage('assets/images/john.png'),

                    ),
                  ),
                ),
                      Positioned(
                        bottom: 15,
                        right: 10,
                        child: InkWell(
                          onTap: () {
                            print('Change the profile picture');
                          },
                          child: Image.asset('assets/images/plusbtn.png'),
                        ),
                      ),
                      Center(
                        child: Container(
                          height: 32.5,
                          width: 35.83,

                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              buildTextField(arrNames[0], firstname, TextInputType.text, 'Full Name', 50), // Example maxLength of 50 characters

              SizedBox(height: 20),
              buildTextField(arrNames[1], mobilenumber, TextInputType.phone, 'Mobile Number', 10), // Example maxLength of 10 digits for phone number
              SizedBox(height: 20),
              buildTextField(arrNames[2], emailadd, TextInputType.emailAddress, 'Email Address', 50), // Example maxLength of 50 characters for email
              SizedBox(height: 20),
              buildTextField(arrNames[3], dob, TextInputType.text, 'Date of Birth', 10), // Example maxLength for date input
              SizedBox(height: 20),
              buildTextField(arrNames[4], gender, TextInputType.text, 'Gender', 10), // Example maxLength for gender input

              SizedBox(height: 20),
              buildTextField(arrNames[5], height, TextInputType.number, 'Height', 3),
              SizedBox(height: 20),
              buildTextField(arrNames[6], weight, TextInputType.number, 'Weight', 3), // Example maxLength for weight (assuming maximum 3 digits)
              SizedBox(height: 20),
              SizedBox(height: 20),
              Container(
                width: double.infinity,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Color.fromRGBO(41, 41, 41, 0.5),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, top: 18),
                  child: Text('Member Id '
                      // '${widget.memberidfromlogin}'
                    ,
                    style: Theme.of(context).textTheme.headlineMedium!.copyWith(fontSize: 16, color: Color(0xFFCCCCCC)),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Container(
                width: double.infinity,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Color.fromRGBO(41, 41, 41, 0.5),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, top: 18),
                  child: Text(
                    'Monthly Subscription',
                    style: Theme.of(context).textTheme.headlineMedium!.copyWith(fontSize: 16, color: Color(0xFFCCCCCC)),
                  ),
                ),
              ),
              SizedBox(height: 25),
              InkWell(
                onTap: () {
                  String firstName = firstname.text;

                  String phnNumber = mobilenumber.text;
                  String emailAddress = emailadd.text;
                  String Dob =dob.text;
                  String gen = gender.text;
                  String hgt = height.text;
                  String wt = weight.text;

                  if (firstName.isNotEmpty

                  // phnNumber.isNotEmpty &&
                  // emailAddress.isNotEmpty &&
                  // doj.isNotEmpty &&
                  // dob.isNotEmpty &&
                  // gen.isNotEmpty &&
                  // hgt.isNotEmpty &&
                  // wt.isNotEmpty)
                  ){
                    // All fields are filled, navigate to the next page
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => profilepage(
                                  firstname.text,
                                  mobilenumber.text,
                                  emailadd.text,
                                  dob.text,
                                  gender.text,
                                  height.text,
                                  weight.text,
                                )));
                  } else {
                    // Handle case where not all fields are filled
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Incomplete Form'),
                        content: Text('Please fill in all fields to continue.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      ),
                    );
                  }
                },
                child: Container(
                  width: double.infinity,
                  height: 52,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Color(0xFFFF6600),
                  ),
                  child: Center(
                    child: Text(
                      'SAVE',
                      style: Theme.of(context).textTheme.headlineMedium!.copyWith(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTextField(String labelText, TextEditingController controller, TextInputType inputType, String validationMessage, int maxLength) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          labelText,
          style: Theme.of(context).textTheme.headlineMedium!.copyWith(fontSize: 16),
        ),
        SizedBox(height: 4),
        TextFormField(
          controller: controller,
          keyboardType: inputType,
          inputFormatters: [
            LengthLimitingTextInputFormatter(maxLength), // Limit input to maxLength characters
            if (inputType == TextInputType.number || inputType == TextInputType.phone)
              FilteringTextInputFormatter.digitsOnly,
          ],
          decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xFFEFEFEF),
            border: InputBorder.none,
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
              borderSide: BorderSide(
                width: 4,
                color: Color(0xFFFF6600),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
              borderSide: BorderSide(
                width: 4,
                color: Color(0xFFEFEFEF),
              ),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return '$validationMessage is required';
            }
            // You can add more specific validation here based on the field name
            // For example, validate email format, phone number format, etc.
            return null;
          },
        ),
      ],
    );
  }


}



import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gymapp/Editprofile.dart';
import 'package:gymapp/home1.dart';
import 'package:gymapp/main.dart';



class profilepage extends StatefulWidget{

  final String p_fullname;
  final String p_phoneno;
  final String p_Gmail;
  final String p_dob;
  final String p_gender;
  final String p_height;
  final String p_weight;
  profilepage(
      this.p_fullname,
      this.p_phoneno,
      this.p_Gmail,
      this.p_dob,
      this.p_gender,
      this.p_height,
      this.p_weight,
      );

  @override
  State<profilepage> createState() => _profilepageState();
}

class _profilepageState extends State<profilepage> {

  List<String> arrdata=[
    'Full Name',
    'Phone Number',
    'Gmail',
    'D.O.B',
    'Gender',
    'Height',
    'Weight',
  ];

  List<String> datavalue =['Nimit Shekhawat',
    '91+ 9467015594',
    'nimitshekhawat2001@gmail.com',
    '15.02.2004',
    'Male',
    '6 ft',
    '67'
  ];
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      datavalue[0] = widget.p_fullname;
      datavalue[1] = widget.p_phoneno;
      datavalue[2] = widget.p_Gmail;
      datavalue[3] = widget.p_dob;
      datavalue[4] = widget.p_gender;
      datavalue[5] = widget.p_height;
      datavalue[6] = widget.p_weight;
    });
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
            onTap: (){
              Navigator.push(context,MaterialPageRoute(builder: (context)=> home1()));
            },
            child: Image.asset('assets/images/backarrow.png')),
        title: Text('Profile Page',
          style: TextStyle(fontFamily: 'Koulen', fontSize: 24,),),
            actions: [
              Container(

                  child: InkWell(
                      onTap: (){
                        Navigator.push(context,
                            MaterialPageRoute(
                                builder: (context)=> Editprofile(
                                  datavalue[0],
                                  datavalue[1],
                                  datavalue[2],
                                  datavalue[3],
                                  datavalue[4],
                                  datavalue[5],
                                  datavalue[6],



                                )));

                      },
                      child:  Image.asset('assets/images/Editprofileicon.png'),),)
            ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 20,right: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 20,
            ),
            Center(
              child: SizedBox(
                height: 150,
                width: 150,
                child: CircleAvatar(
                  minRadius: 150,
                  maxRadius: 150,
                  backgroundImage: AssetImage('assets/images/john.png'),

                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: 500,
              
              child: ListView.separated(itemBuilder: (context,index){
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Text(arrdata[index],style: TextStyle(fontFamily: 'poppins',fontSize: 12,color:CupertinoColors.systemGrey ),),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text('  ${datavalue[index]}',style: TextStyle(fontFamily: 'poppins',fontSize: 16,color:Colors.black,fontWeight: FontWeight.bold)),
                    SizedBox(
                      height: 5,
                    ),
                  ],
                );
              }, separatorBuilder: (context,index){
                return Divider(
                  height: 1,
                  color: Colors.black12,
                );
              }, itemCount: arrdata.length),
            ),
            SizedBox(
              height: 5,
            ),
            InkWell(
                onTap: (){
                  print('logout');
                  Opendialog(context);
                  },

                child: Text('Logout',style: TextStyle(fontFamily: 'poppins',fontSize: 16,color:Colors.black,fontWeight: FontWeight.bold))),





          ],
        ),
      ),
    );
  }
}
void Opendialog(BuildContext context) { // Accept context as parameter
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: Colors.white,
        elevation: 0,
        child: Container(
          height: 310,
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [

              Center(
                child: Text(
                  'Logout Account',
                  style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'poppins', fontSize: 18),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Text(
                  'Are you sure you want to logout the account?',
                  style: TextStyle(fontFamily: 'poppins', fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Container(
                  height: 46,
                  width: 46,
                  child: Image.asset('assets/images/logout/Log_Out.png'),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              InkWell(
                onTap: () {

                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => MyHomePage()), // Replace with your login page
                        (Route<dynamic> route) => false, // Remove all routes in the stack
                  );
                },
                child: Container(
                  height: 55,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(29)

                  ),

                  child: Center(
                    child: Text(
                      'Yes',
                      style: TextStyle(fontFamily: 'poppins', fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 3,
              ),
              InkWell(
                onTap: () {
                  Navigator.pop(context); // Close the dialog
                },
                child: Container(
                  height: 55,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(29),
                  ),
                  child: Center(
                    child: Text(
                      'No',
                      style: TextStyle(fontFamily: 'poppins', fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(29),
          ),
        ),
      );
    },
  );
}
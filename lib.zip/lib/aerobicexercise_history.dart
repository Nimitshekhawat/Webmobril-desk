import 'package:flutter/material.dart';



class aeroexerhistory extends StatefulWidget {
  const aeroexerhistory({super.key});

  @override
  State<aeroexerhistory> createState() => _aeroexerhistoryState();
}

class _aeroexerhistoryState extends State<aeroexerhistory> {

  late Color aerobictextcolor=Colors.black;
  late Color exercisetextcolor=Colors.black;


  bool aerobicbtn=false;
  bool exercisebtn=false;



  Map<int, Color> colorbtn = {
    0: Colors.white,
    1: Colors.white,
  };


  @override
  void initState() {
    super.initState();
    setState(() {

      colorbtn[0] = Colors.deepOrange;
      aerobicbtn = true;

      aerobictextcolor=Colors.white;
      exercisetextcolor=Colors.black;

    });
  }

  void btncolordecider() {
    setState(() {
      if (aerobicbtn == false && exercisebtn == true) {
        exercisetextcolor = Colors.white;
        colorbtn[1] = Colors.deepOrange;
        colorbtn[0] = Colors.white;
        aerobictextcolor = Colors.black;
        exercisebtn = true;

      }
      else {
        aerobictextcolor = Colors.white;
        exercisetextcolor = Colors.black;
        colorbtn[0] = Colors.deepOrange;
        colorbtn[1] = Colors.white;
        aerobicbtn = true;
        exercisebtn = false;
      }
    });


  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text( 'Workout History',style: TextStyle(fontFamily: 'Koulen'),),  
      ),

        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(left: 20,right:20),
            child: Container(
                height: double.infinity,
                child: Column(children: [
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(25),
                      border: Border.all(width: 1, color: Colors.black12),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                exercisebtn = false;
                                aerobicbtn = true;
                                btncolordecider();
                              });
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(25),
                                color: colorbtn[0],
                              ),
                              child: Center(
                                  child: Text(
                                'Aerobic',
                                style: TextStyle(
                                    fontFamily: 'Koulen',
                                    fontSize: 18,
                                    color: aerobictextcolor),
                              )),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: InkWell(
                            onTap: () {
                              aerobicbtn = false;
                              exercisebtn = true;
                              btncolordecider();

                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(25),
                                color: colorbtn[1],
                              ),
                              child: Center(
                                  child: Text(
                                'Exercise',
                                style: TextStyle(
                                    fontFamily: 'Koulen',
                                    fontSize: 18,
                                    color: exercisetextcolor),
                              )),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),

                  aerobicbtn==true ? aerobictable() :exercisetable(),

                ])),
          ),
        ));
    
    
  }
}


class aerobictable extends StatefulWidget{
  @override
  State<aerobictable> createState() => _aerobictableState();
}

class _aerobictableState extends State<aerobictable> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
        height: 620,
      child: SingleChildScrollView(
        child: Column(
          children: [
            Table(
              columnWidths: const{
                0: FlexColumnWidth(1),
                1: FlexColumnWidth(1),
                2: FlexColumnWidth(1),
              },
              border: TableBorder.all(color:Colors.black45,borderRadius: BorderRadius.circular(20)),
              children: [
                TableRow(

                  decoration: BoxDecoration(color: Colors.black12),
                  children: [
                    TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(15.0), child: Text( 'DATE',style: TextStyle(fontFamily: 'poppins'),)))),
                    TableCell(child: Center(child: Padding(padding: const EdgeInsets.only(top: 15.0), child: Text('MILES', )))),
                    TableCell(child: Center(child: Padding(padding: const EdgeInsets.only(top: 15.0), child: Text( 'SPEED', )))),

                  ],
                ),
                ...aerobicdata.map((data) {
                  return TableRow(
                    children: [
                      TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(10.0), child: Text( data.date,style: TextStyle(fontFamily:  'poppins',
                          fontSize: 12,fontWeight: FontWeight.w400),)))),
                      TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(10.0), child: Text( data.miles,style: TextStyle(fontFamily:  'poppins',
                          fontSize: 12,fontWeight: FontWeight.w400),)))),
                      TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(10.0), child: Text( data.speed,style: TextStyle(fontFamily:  'poppins',
                          fontSize: 12,fontWeight: FontWeight.w400),)))),

                    ],
                  );
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class aerobicexerciseentry {
  final String date;
  final String miles;
  final String speed;


  aerobicexerciseentry({required this.date, required this.miles, required this.speed});
}


List<aerobicexerciseentry> aerobicdata = [

  aerobicexerciseentry(date: '2024-06-28', miles: '10 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-03-28', miles: '20 miles', speed: '26'),
  aerobicexerciseentry(date: '2024-11-28', miles: '30 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-10-28', miles: '40 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-02-28', miles: '50 miles', speed: '6'),
  aerobicexerciseentry(date: '2024-03-28', miles: '60 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-04-28', miles: '70 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-05-28', miles: '80 miles', speed: '36'),

  aerobicexerciseentry(date: '2024-03-28', miles: '60 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-04-28', miles: '70 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-05-28', miles: '80 miles', speed: '36'),aerobicexerciseentry(date: '2024-06-28', miles: '10 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-03-28', miles: '20 miles', speed: '26'),
  aerobicexerciseentry(date: '2024-11-28', miles: '30 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-10-28', miles: '40 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-02-28', miles: '50 miles', speed: '6'),
  aerobicexerciseentry(date: '2024-03-28', miles: '60 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-04-28', miles: '70 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-05-28', miles: '80 miles', speed: '36'),

  aerobicexerciseentry(date: '2024-03-28', miles: '60 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-04-28', miles: '70 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-05-28', miles: '80 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-06-28', miles: '10 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-03-28', miles: '20 miles', speed: '26'),
  aerobicexerciseentry(date: '2024-11-28', miles: '30 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-10-28', miles: '40 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-02-28', miles: '50 miles', speed: '6'),
  aerobicexerciseentry(date: '2024-03-28', miles: '60 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-04-28', miles: '70 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-05-28', miles: '80 miles', speed: '36'),

  aerobicexerciseentry(date: '2024-03-28', miles: '60 miles', speed: '46'),
  aerobicexerciseentry(date: '2024-04-28', miles: '70 miles', speed: '36'),
  aerobicexerciseentry(date: '2024-05-28', miles: '80 miles', speed: '36'),


];



//for exercise table

class exercisetable extends StatefulWidget{
  @override
  State<exercisetable> createState() => _exercisetableState();
}

class _exercisetableState extends State<exercisetable> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 620,
      child: SingleChildScrollView(
        child: Column(
          children: [
            Table(
              columnWidths: const{
                0: FlexColumnWidth(1),
                1: FlexColumnWidth(1),
                2: FlexColumnWidth(1),
                3: FlexColumnWidth(1),
              },
              border: TableBorder.all(color:Colors.black45,borderRadius: BorderRadius.circular(20)),
              children: [
                TableRow(

                  decoration: BoxDecoration(color: Colors.black12),
                  children: [
                    TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(15.0), child: Text( 'DATE',style: TextStyle(fontFamily: 'poppins'),)))),
                    TableCell(child: Center(child: Padding(padding: const EdgeInsets.only(top: 15.0), child: Text('REPS', )))),
                    TableCell(child: Center(child: Padding(padding: const EdgeInsets.only(top: 15.0), child: Text( 'SETS', )))),
                    TableCell(child: Center(child: Padding(padding: const EdgeInsets.only(top: 15.0), child: Text( 'WEIGHT', )))),

                  ],
                ),
                ...exerciseData.map((data) {
                  return TableRow(
                    children: [
                      TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(10.0), child: Text( data.date,style: TextStyle(fontFamily:  'poppins',
                          fontSize: 12,fontWeight: FontWeight.w400),)))),
                      TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(10.0), child: Text( data.reps,style: TextStyle(fontFamily:  'poppins',
                          fontSize: 12,fontWeight: FontWeight.w400),)))),
                      TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(10.0), child: Text( data.sets,style: TextStyle(fontFamily:  'poppins',
                          fontSize: 12,fontWeight: FontWeight.w400),)))),
                      TableCell(child: Center(child: Padding(padding: const EdgeInsets.all(10.0), child: Text( data.weight,style: TextStyle(fontFamily:  'poppins',
                          fontSize: 12,fontWeight: FontWeight.w400),)))),

                    ],
                  );
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ExerciseEntry {
  final String date;
  final String reps;
  final String sets;
  final String weight;

  ExerciseEntry({
    required this.date,
    required this.reps,
    required this.sets,
    required this.weight
  });


}


List<ExerciseEntry> exerciseData = [

  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'3',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'4',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'15',sets:'3',weight: '10 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'12',sets:'4',weight: '25 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'3',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'4',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'15',sets:'3',weight: '10 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'12',sets:'4',weight: '25 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'3',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'4',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'15',sets:'3',weight: '10 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'12',sets:'4',weight: '25 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'3',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'10',sets:'4',weight: '5 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'15',sets:'3',weight: '10 LBS' ),
  ExerciseEntry(date: '2024-06-28', reps:'12',sets:'4',weight: '25 LBS' ),



];


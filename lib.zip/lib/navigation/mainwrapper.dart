import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';
import 'package:spotsball_app/screens/Homepage_screens/homepage.dart';
import 'package:spotsball_app/screens/More_Section/Morepage.dart';
import 'package:spotsball_app/screens/More_Section/play.dart';

class mainwrapper extends StatefulWidget {
  const mainwrapper({super.key});

  @override
  State<mainwrapper> createState() => _mainwrapperState();
}

class _mainwrapperState extends State<mainwrapper> {

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();


  List<Widget> buildScreens() {
    return <Widget>[
      play(),
      homepage(),
      Morepage()
    ];
  }

  @override
  Widget build(BuildContext context) {
    List<PersistentBottomNavBarItem> navBarsItems() {
      return [
        PersistentBottomNavBarItem(
          icon: Image.asset('assets/images/Help_image.png',height: 18),
          title: ("Help"),
          iconSize: 18,

          textStyle: TextStyle(color: Colors.white, fontSize: 8),
          activeColorPrimary: Color(0xFF7CAB05),
          inactiveColorPrimary: Colors.white,
        ),
        PersistentBottomNavBarItem(
          icon: Image.asset('assets/images/Home_image.png',height: 18),
          iconSize: 18,

          title: ("Home"),
          textStyle: TextStyle(color: Colors.white, fontSize: 8),
          activeColorPrimary: Color(0xFF7CAB05),
          inactiveColorPrimary: Colors.white,
        ),

        PersistentBottomNavBarItem(

          icon: Image.asset('assets/images/more_image.png',height: 18,),

          iconSize:18,
          title: ("More"),
          textStyle: TextStyle(color: Colors.white, fontSize: 8),
          activeColorPrimary: Color(0xFF7CAB05),
          inactiveColorPrimary: Colors.white,
        ),

      ];
    }
    PersistentTabController controller = PersistentTabController(initialIndex: 1);

    return Scaffold(
      backgroundColor: Color(0xffF8F8FF),
      key: _scaffoldKey,

      body: PersistentTabView(
        context,
        controller: controller,
        screens: buildScreens(),
        items: navBarsItems(),
        navBarHeight: 61,
        confineToSafeArea: true,
        backgroundColor: Color(0xFF00326C),
        // Set the background color here
        handleAndroidBackButtonPress: true,
        resizeToAvoidBottomInset: true,
        stateManagement: true,
        hideNavigationBarWhenKeyboardAppears: true,
        decoration: NavBarDecoration(

          borderRadius: BorderRadius.only(topLeft: Radius.circular(10),topRight: Radius.circular(10)),
          colorBehindNavBar: Colors.white,
        ),
        onItemSelected: (index) {

        },
        popBehaviorOnSelectedNavBarItemPress: PopBehavior.all,
        // popAllScreensOnTapOfSelectedTab: false,
        // popActionScreens: PopActionScreensType.all,
        // itemAnimationProperties: const ItemAnimationProperties(
        //   duration: Duration(milliseconds: 0), // Reduce or eliminate animation duration
        //   curve: Curves.ease,
        // ),
        // screenTransitionAnimation: const ScreenTransitionAnimation(
        //   animateTabTransition: false, // Disable tab transition animation
        //   curve: Curves.ease,
        //   duration: Duration(milliseconds: 0), // Reduce or eliminate animation duration
        // ),
        navBarStyle: NavBarStyle.simple, // Choose a style that suits your design
      ),
    );
  }

}



